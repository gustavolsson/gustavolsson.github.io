# Sailor
# A game made in 48 hours by Gustav Olsson

# Controls
Move the mouse and left click to add a piece to your boat, right click to remove it
Left and Right arrow keys moves your boat

Note that you can paint your ship while sailing!

# Tools used
Visual C++ .Net 2005 Express
Allegro game library

# Redistributable files (most people have these)
http://www.microsoft.com/downloads/details.aspx?familyid=32bc1bee-a3f9-4c13-9c99-220b62a191ee&displaylang=en

# Copyright 2008 Gustav Olsson (source and binary)
You may not copy the source (Source.zip, including compressed files) directly, but you may use it for educational purposes.